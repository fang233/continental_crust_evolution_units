# Continental crustal units based on same background and similar background
import math
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import FFunction
def sameBackground(x,y,com_gridCluster_result,require_len):
    # clustering
    # final_draw represents the different peak combinations of basic grids; final_drawNumber represents the clusters of basic grids
    final_draw = [-1 for i in range(x * y)]
    final_drawNumber = [-1 for i in range(x * y)]

    final_peakCom_indexs = []
    final_drawNumber_clusters = []
    final_peakCom_numbers = []
    peakCom_count = 1

    for every_peakCom_index in range(len(com_gridCluster_result)):
        # if this peak combination contains clusters
        if len(com_gridCluster_result[every_peakCom_index]) != 0:
            # to judge whether clusters are qualified
            judge = False
            for every_cluster in com_gridCluster_result[every_peakCom_index]:
                if len(every_cluster) >= require_len:
                    judge = True
                    break
            # if at least one cluster is qualified,final_draw will remember this cluster and its corresponding peak combination
            if judge:
                final_peakCom_indexs.append(every_peakCom_index)
                peakCom_cluster_count = 0
                for every_cluster in com_gridCluster_result[every_peakCom_index]:
                    if len(every_cluster) >= require_len:
                        print('qualified clusters:', every_cluster)
                        cluster_number = peakCom_count * 10 + peakCom_cluster_count
                        final_drawNumber_clusters.append(every_cluster)
                        final_peakCom_numbers.append(cluster_number)
                        for every_grid in every_cluster:
                            final_draw[every_grid] = peakCom_count
                            final_drawNumber[every_grid] = cluster_number
                        peakCom_cluster_count += 1
                    else:  # grids belonging to unqualified clusters need to be changed
                        for every_grid in every_cluster:
                            final_draw[every_grid] = 0

                peakCom_count += 1
            else:
                for every_cluster in com_gridCluster_result[every_peakCom_index]:
                    for every_grid in every_cluster:
                        final_draw[every_grid] = 0

    return final_draw,final_drawNumber,final_peakCom_indexs,peakCom_count
def similarBackground(x,y,com_gridCluster_result,grid_numberList,no_age_gridList,gridPeakNumberSim,peak_combinationList,require_len):
    # final_draw represents the different peak combinations of basic grids; final_drawNumber represents the clusters of basic grids
    final_draw = [-1 for i in range(x * y)]
    final_drawNumber = [-1 for i in range(x * y)]

    need_to_change_grids = []
    not_peakCom_index = []
    final_peakCom_indexs = []
    final_drawNumber_clusters = []
    final_peakCom_numbers = []
    peakCom_count = 1

    for every_peakCom_index in range(len(com_gridCluster_result)):
        # if this peak combination contains clusters
        if len(com_gridCluster_result[every_peakCom_index]) != 0:
            # to judge whether clusters are qualified
            judge = False
            for every_cluster in com_gridCluster_result[every_peakCom_index]:
                if len(every_cluster) >= require_len:
                    judge = True
                    break
            # if at least one cluster is qualified,final_draw will remember this cluster and its corresponding peak combination
            if judge:
                final_peakCom_indexs.append(every_peakCom_index)
                peakCom_cluster_count = 0
                for every_cluster in com_gridCluster_result[every_peakCom_index]:
                    if len(every_cluster) >= require_len:
                        print('qualified clusters:', every_cluster)
                        cluster_number = peakCom_count * 10 + peakCom_cluster_count
                        final_drawNumber_clusters.append(every_cluster)
                        final_peakCom_numbers.append(cluster_number)
                        for every_grid in every_cluster:
                            final_draw[every_grid] = peakCom_count
                            final_drawNumber[every_grid] = cluster_number
                        peakCom_cluster_count += 1
                    else:  # grids belonging to unqualified clusters need to be changed
                        for every_grid in every_cluster:
                            need_to_change_grids.append(every_grid)
                peakCom_count += 1
            else:
                not_peakCom_index.append(every_peakCom_index)
                for every_cluster in com_gridCluster_result[every_peakCom_index]:
                    for every_grid in every_cluster:
                        need_to_change_grids.append(every_grid)

    # To adjust the peak combinations of unqualified grids
    need_to_change_grids_copy = need_to_change_grids[:]
    # grids which are hard to be clustered
    difficult_judge_grids = []
    while len(need_to_change_grids_copy) != 0:
        gridNumber = need_to_change_grids_copy[0]
        round_gridNumber = [gridNumber - x, gridNumber + x, gridNumber - 1, gridNumber + 1, gridNumber - x - 1,
                            gridNumber + x + 1, gridNumber - x + 1, gridNumber + x - 1]
        # round_grid_counts represents the number of grids which are adjacent to central grid
        round_grid_counts = 0
        for rounds in round_gridNumber:
            if rounds in grid_numberList:
                round_grid_counts += 1
        # To judge the situation of adjacent grids
        no_age_counts = 0
        belong_cluster_grids = []
        belong_change_grids = []

        for rounds in round_gridNumber:
            # this adjacent grid has no age data
            if rounds in no_age_gridList:
                no_age_counts += 1
            # this adjacent grid belongs to grids of which peak combination need to change
            elif rounds in need_to_change_grids:
                belong_change_grids.append(rounds)
            # this adjacent grid is qualified
            elif (rounds not in need_to_change_grids) and rounds < x * y:
                belong_cluster_grids.append(rounds)

        # this central grid is surrounded by grids without data
        if no_age_counts == round_grid_counts:
            need_to_change_grids_copy.pop(0)
            final_draw[gridNumber] = 0
        # there at least one adjacent grid with age data
        elif len(belong_cluster_grids) != 0:
            select_peakCom_index, select_roundGrid = FFunction.compareSimilar(gridNumber, belong_cluster_grids,
                                                                    gridPeakNumberSim, peak_combinationList)
            gridPeakNumberSim[gridNumber] = select_peakCom_index
            final_draw[gridNumber] = final_draw[select_roundGrid]
            final_drawNumber[gridNumber] = final_drawNumber[select_roundGrid]
            final_drawNumber_clusters[final_peakCom_numbers.index(final_drawNumber[gridNumber])].append(gridNumber)
            need_to_change_grids_copy.pop(0)
            need_to_change_grids.pop(need_to_change_grids.index(gridNumber))
        else:
            if difficult_judge_grids.count(gridNumber) == 10:
                final_draw[gridNumber] = 0
                need_to_change_grids_copy.pop(0)
            else:
                select_peakCom_index, select_roundGrid = FFunction.compareSimilar(gridNumber, belong_change_grids,
                                                                        gridPeakNumberSim, peak_combinationList)
                gridPeakNumberSim[gridNumber] = select_peakCom_index
                need_to_change_grids_copy.pop(0)
                need_to_change_grids_copy.append(gridNumber)
                difficult_judge_grids.append(gridNumber)

    return final_draw,final_drawNumber,final_peakCom_indexs,peakCom_count
def main():
    print('This code is to acquire continental crustal units under the rules of same background or similar background')
    # 1.getting data
    conInfo = FFunction.readFile(
        input('Please type the filename(example: Part of Chinese zircon U-Pb chronology database.csv):'))
    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    number = len(choseAge)

    # 2.setting the range of latitude, longitude, and the scale of grid
    # EM means the extreme east, WM means the extreme west, SM means the extreme south, and NM means extreme north
    # x represents the number of grids along longitude while y represents the number of grids along latitude
    EM, WM, SM, NM = 140, 70, 16, 55
    internal = 1
    x, y = math.ceil((EM - WM) / internal), math.ceil((NM - SM) / internal)
    # the required number of basic grids for every qualified continental crustal units
    require_len = 2

    # 3.putting ages into the grids that they belong to
    grid_conAge = [[] for i in range(x * y)]
    grid_numberList = [i for i in range(x * y)]
    for i in range(number):
        try:
            count = int((float(lon[i]) - WM) // internal) + (int(float((lat[i]) - SM) // internal)) * x
            grid_conAge[count].append(choseAge[i])
        except:
            continue

    # 4.no_age_gridList collects grids without data
    no_age_gridList = []
    for every_grid in range(len(grid_conAge)):
        if len(grid_conAge[every_grid]) == 0:
            no_age_gridList.append(every_grid)

    # 5. getting the peak combinations of every basic grid
    peakList = [45.47191501721, 132.02488348912564, 249.07083787994625, 440.8688987552644, 814.99252896288,
                1235.5880341203751, 1908.2750689880334, 2505.1741828979793, 2932.733387973]
    sigmaList = [23.50208485387001, 22.11961839983983, 47.74288173121555, 48.247783434211065, 91.98571575449814,
                 190.4293589626058, 152.2596776296344, 90.00529650075231, 378.0092872606897]
    peak_count = len(peakList)
    # getting simplified peak combinations of basic grids
    gridPeakNumberSim, peak_combinationList = FFunction.peakComSimInGrid(grid_conAge, peakList, sigmaList, 2)
    # getting clusters
    com_gridCluster_result = FFunction.peakComGridCluster(gridPeakNumberSim, grid_numberList, peak_count, x)

    # 6. choosing rules of clustering
    same_or_similar=input('Please choose same or similar:')
    if same_or_similar=='same':
        final_draw, final_drawNumber, final_peakCom_indexs, peakCom_count = sameBackground(x, y, com_gridCluster_result,
                                                                                           require_len)
    elif same_or_similar=='similar':
        final_draw,final_drawNumber,final_peakCom_indexs,peakCom_count=similarBackground(x,y,com_gridCluster_result,grid_numberList,no_age_gridList,gridPeakNumberSim,peak_combinationList,require_len)

    # 7. "0" represents grids without data
    for grid in no_age_gridList:
        final_draw[grid] = 0
    # 8.drawing
    # setting the labels of the colorbar
    labels = [['noData']] + [[] for i in range(peakCom_count - 1)]
    for i in range(len(final_peakCom_indexs)):
        if len(peak_combinationList[final_peakCom_indexs[i]]):
            for j in peak_combinationList[final_peakCom_indexs[i]]:
                tem = int(round(peakList[j]))
                labels[i + 1].append(tem)
    for i in range(len(labels)):
        labels[i].insert(0, str(i))


    for i in range(len(labels)):
        labels[i]=str(labels[i])[1:-1]

    final_draw = np.array(final_draw).reshape(y, x)
    final_drawNumber = np.array(final_drawNumber).reshape(y, x)

    lons = np.linspace(WM, WM + x * internal, x + 1)
    lats = np.linspace(SM, SM + y * internal, y + 1)
    lon, lat = np.meshgrid(lons, lats)

    # setting colorbar
    plt.rcParams['font.sans-serif'] = ['Times New Roman']  # setting font
    my_colors = FFunction.colormap0(peakCom_count - 1)
    fig = plt.figure(figsize=(30.0, 16.0))
    fig.add_subplot(111)
    m = Basemap(llcrnrlon=70, urcrnrlon=140, llcrnrlat=15, urcrnrlat=55)
    m.drawcoastlines()
    parallels = np.arange(15., 55, 10.)
    m.drawparallels(parallels, labels=[False, True, True, False])
    meridians = np.arange(70., 140., 10.)
    m.drawmeridians(meridians, labels=[True, False, False, True])
    m.readshapefile('gadm36_CHN_1', 'state',drawbounds=True,color='black',linewidth=0.5)
    m.readshapefile('Country', 'Country', drawbounds=True, color='black', linewidth=0.5)
    province_location = {'Anhui': (116, 32), 'Beijing': (116, 40), 'Chongqing': (106, 29), 'Fujian': (117, 26),
                         'Gansu': (100.5, 38), 'Guangdong': (113, 24), 'Guangxi': (108, 24), 'Guizhou': (106, 27),
                         'Hainan': (109, 19), 'Hebei': (115, 38),
                         'Heilongjiang': (127, 46), 'Henan': (113, 34), 'Hubei': (112, 30.5), 'Hunan': (111, 28),
                         'Jiangsu': (118, 33), 'Jiangxi': (115, 28), 'Jilin': (125, 44), 'Liaoning': (121.5, 41.5),
                         'Nei Mongol': (110, 42), 'Ningxia': (105, 37),
                         'Qinghai': (95, 36), 'Shaanxi': (107.5, 34), 'Shandong': (117, 35.5),
                         'Shanghai': (121, 31), 'Shanxi': (111, 37), 'Sichuan': (102, 30), 'Tianjin': (116, 39),
                         'Xinjiang Uygur': (85, 40), 'Tibet': (89, 30), 'Yunnan': (101, 25),
                         'Zhejiang': (119, 28.5), 'Taiwan': (120, 23.5)}
    for key in province_location.keys():
        lons = province_location[key][0]
        lats = province_location[key][1]
        lons, lats = m(lons, lats)
        plt.text(lons, lats, key, fontsize=10, color='black')
    # writing the index of peak combinations
    for i in range(y):
        for j in range(x):
            if final_drawNumber[i, j] >= 10:
                index_of_peak_combination=math.floor(final_drawNumber[i, j]/10)
                plt.text(WM + j * internal, SM + i * internal, index_of_peak_combination, fontsize=6, color="w")
    Ax, Ay = m(lon, lat)
    datamap = m.pcolor(Ax, Ay, final_draw, cmap=my_colors)
    cb = plt.colorbar(datamap, cmap=my_colors, ticks=[i for i in range(peakCom_count)])
    cb.set_ticklabels(labels, update_ticks=True)
    plt.show()


if __name__ == '__main__':
    main()