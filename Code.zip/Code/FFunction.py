import sys
from itertools import combinations
import math
import numpy as np
import matplotlib.colors as colors
from sklearn import mixture

#------------------------------------------------------------------------------------
#For reading file
def readFile(filename):
    file = open(filename)
    fileContent = file.read().splitlines()  # return as a list with previous rows as items in this list
    fileContent.pop(0) # delete the header
    lens=len(fileContent)
    for i in range(lens):
        fileContent[i] = eval(fileContent[i])
    file.seek(0)
    file.close()
    return fileContent
#------------------------------------------------------------------------------------
# For transferring three kinds of age data into single age data under the rule of the recommended age
# conInfo represents the data including number, there kinds of age and their sigma and GPS; point6875 and point7576 represent the turning points of the recommended age

def simpleData(conInfo,point6875,point7576):
    choseAgeN,choseAge,lon,lat=[],[],[],[]
    lenss=len(conInfo)
    for i in range(lenss):
        if conInfo[i][1]!=None:
            if 0<=conInfo[i][1]<=point6875:
                choseAge.append(conInfo[i][1])
                choseAgeN.append(conInfo[i][0])
                lon.append(conInfo[i][7])
                lat.append(conInfo[i][8])
        if conInfo[i][3]!=None:
            if point6875<=conInfo[i][3]<=point7576:
                choseAge.append(conInfo[i][3])
                choseAgeN.append(conInfo[i][0])
                lon.append(conInfo[i][7])
                lat.append(conInfo[i][8])
        if conInfo[i][5]!=None:
            if point7576<=conInfo[i][5]<=4600:
                choseAge.append(conInfo[i][5])
                choseAgeN.append(conInfo[i][0])
                lon.append(conInfo[i][7])
                lat.append(conInfo[i][8])
    return choseAge,choseAgeN,lon,lat
# ------------------------------------------------------------------------------------
# For choosing the most similar adjacent grid with central grid
def compareSimilar(centerGrid, roundGrids, gridPeakNumberSim, peak_combinationList):
    roundScores = []
    for round_grid in roundGrids:
        center_peakCom = peak_combinationList[gridPeakNumberSim[centerGrid]]
        round_peakCom = peak_combinationList[gridPeakNumberSim[round_grid]]
        if len(center_peakCom) == 0 and len(round_peakCom) == 0:
            temScore = 1
        else:
            intersection = len(set(center_peakCom).intersection(set(round_peakCom)))
            temScore = intersection / (len(center_peakCom) + len(round_peakCom) - intersection)
        roundScores.append(temScore)
    select = roundScores.index(max(roundScores))
    select_roundGrid = roundGrids[select]
    select_peakCom_index = gridPeakNumberSim[roundGrids[select]]
    return select_peakCom_index, select_roundGrid


# ------------------------------------------------------------------------------------
# For setting color map，n<=34 (n represents the number of colors)
def colormap0(n):
    color0 = ['white']
    color1 = ['red', 'purple', 'yellow', 'green', 'blue', 'gainsboro']
    color2 = ['firebrick', 'violet', 'orange', 'olive', 'lightseagreen', 'silver']
    color3 = ['salmon', 'magenta', 'gold', 'lawngreen', 'darkcyan']
    color4 = ['sienna', 'deeppink', 'tan', 'palegreen', 'aqua']
    color5 = ['chocolate', 'pink', 'palegoldenrod', 'yellowgreen', 'deepskyblue']
    color6 = ['peachpuff', 'darkviolet', 'darkgoldenrod', 'springgreen', 'skyblue']
    color7 = ['indigo', 'dodgerblue']
    color8 = ['navy', 'lightyellow']
    full_color = color0 + color1 + color2 + color3 + color4 + color5 + color6 + color7 + color8
    return colors.ListedColormap(full_color[:n], 'indexed')
#------------------------------------------------------------------------------------
# For getting the results of Gaussian fitting
def gaussianS(choseAge):
    if len(choseAge)==0:
        return [],[],[]
    else:
        choseAge = np.array(choseAge)[:, np.newaxis]
        lowest_bic = 10000000
        n_components_range = range(1, 10)
        for n_components in n_components_range:
            if len(choseAge) >n_components:
                # Fit a Gaussian mixture with EM
                gmm = mixture.GaussianMixture(n_components=n_components,
                                              covariance_type='spherical')
                gmm.fit(choseAge)
                tem_bic=gmm.bic(choseAge)
                if tem_bic < lowest_bic:
                    lowest_bic=tem_bic
                    best_gmm = gmm
        peakList = []
        sigmaList = []
        weightList=[]
        try:
            for i in best_gmm.means_:
                peakList+=list(i)
            sigmaList=list(best_gmm.covariances_)
            for i in range(len(sigmaList)):
                sigmaList[i]=math.sqrt(sigmaList[i])
            weightList = list(best_gmm.weights_)
        except:
            pass
        c=list(zip(peakList,sigmaList,weightList))
        c.sort()
        peakList[:],sigmaList[:],weightList[:]=zip(*c)
    return peakList,sigmaList,weightList
#------------------------------------------------------------------------------------
# For ensuring and simplifying peak combinations of basic grids
def peakComSimInGrid(part_grid_conAge,peakList,sigmaList,times):
    # 1.To judge whether certain peak is in a basic grid
    grid_count=len(part_grid_conAge)
    peak_count=len(peakList)
    # gridPeakNumber contains the index of every peak in basic grids
    gridPeakNumber = [[] for i in range(grid_count)]
    for everyGrid in range(grid_count):
        everyGrid_ageCount = len(part_grid_conAge[everyGrid])
        for everyAge in range(everyGrid_ageCount):
            for peak in range(peak_count):
                if peak not in gridPeakNumber[everyGrid]:
                    left = peakList[peak] - times * sigmaList[peak]
                    right = peakList[peak] + times * sigmaList[peak]
                    if left <= part_grid_conAge[everyGrid][everyAge] <= right:
                            gridPeakNumber[everyGrid].append(peak)
    # 2.To simplify the peak combinations of basic grids
    peak_countList = [i for i in range(peak_count)]
    peak_combinationList = []
    for i in range(peak_count):
        peak_combinationList = peak_combinationList + list(combinations(peak_countList, i + 1))
    peak_combinationList.append(())
    peak_comCount=2**peak_count
    gridPeakNumberSim = [ peak_comCount-1 for i in range(len(gridPeakNumber))]
    grid_count=len(gridPeakNumber)
    for i in range(grid_count):
        for j in range(peak_comCount-1):
            if len(list(set(gridPeakNumber[i]).difference(set(peak_combinationList[j])))) == 0 and len(
                    list(set(peak_combinationList[j]).difference(set(gridPeakNumber[i])))) == 0:
                gridPeakNumberSim[i] = j
    return gridPeakNumberSim,peak_combinationList
#------------------------------------------------------------------------------------
# For dividing grids according to location
# This is an auxiliary function of function named peakComGridCluster
# return:
def diguiCluster(gridNumber,single_com_grid,x):
    round_gridNumber = [gridNumber - x, gridNumber + x, gridNumber - 1, gridNumber + 1, gridNumber - x - 1,
                        gridNumber + x + 1, gridNumber - x + 1, gridNumber + x - 1]
    not_in_count=0
    tem_cluster=[]
    for i in range(len(round_gridNumber)):
        if round_gridNumber[i] not in single_com_grid:
            not_in_count+=1
        else:
            tem_cluster.append(round_gridNumber[i])
            single_com_grid.pop(single_com_grid.index(round_gridNumber[i]))
    if not_in_count==len(round_gridNumber):
        return [gridNumber]
    else:
        result=[gridNumber]
        for i in tem_cluster:
            result+=diguiCluster(i,single_com_grid,x)
        return result
#------------------------------------------------------------------------------------
# For requiring clusters according to simplified peak combinations of basic grids
# a key function
# return: the clusters of every peak combinations.
def peakComGridCluster(gridPeakNumberSim,grid_numberList,peak_count,x):
    sys.setrecursionlimit(1000000)
    peak_comCount = 2 ** peak_count
    grid_count = len(gridPeakNumberSim)
    # 1. putting the index of grid into the list of its corresponding peak combinations
    com_grid = [[] for i in range(peak_comCount)]

    for everyGrid in range(grid_count):
        for comCount in range(peak_comCount):
            # the index of grid's corresponding peak combinations
            if gridPeakNumberSim[everyGrid] == comCount:
                com_grid[comCount].append(grid_numberList[everyGrid])  # the list of this grid's corresponding peak combinations would add the index of this grid
                break

    # 2. reclustering according to the location
    com_gridCluster_result =[[] for i in range(peak_comCount)]
    single_com_grid_count=0
    for single_com_grid in com_grid:
        if len(single_com_grid)!=0:
            gridNumber = single_com_grid[0]
            final_result = []
            while len(single_com_grid) != 0:
                single_com_grid.pop(0)
                result = diguiCluster(gridNumber, single_com_grid, x)
                final_result.append(result)
                for i in result:
                    try:
                        single_com_grid.pop(single_com_grid.index(i))
                    except:
                        continue
                if len(single_com_grid) != 0:
                    gridNumber = single_com_grid[0]

            com_gridCluster_result[single_com_grid_count]=final_result
        single_com_grid_count += 1
    return com_gridCluster_result




