#For the results of Gaussian fitting
import matplotlib.pyplot as plt
import numpy as np
import math
import FFunction
def main():
    # 1.getting data
    conInfo = FFunction.readFile(input('Please type the filename(example: Part of Chinese zircon U-Pb chronology database.csv):'))

    # 2.getting the fitting results
    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    colors = ['tomato', 'hotpink', 'darkblue', 'darkviolet', 'limegreen', 'darkcyan', 'darkorange', 'blanchedalmond',
              'blue']
    peakList, sigmaList, weightList=FFunction.gaussianS(choseAge)
    print('peak:',peakList)
    print('sigma:',sigmaList)
    print('weight:',weightList)

    # 3.drawing
    plt.figure()
    plt.hist(choseAge, density=1, bins=300, color="darksalmon")

    for i in range(len(peakList)):
        x = np.linspace(peakList[i] - 3 * sigmaList[i], peakList[i] + 3 * sigmaList[i], 50)
        y_sig = weightList[i]*np.exp(-(x - peakList[i]) ** 2 / (2 * sigmaList[i] ** 2)) / (math.sqrt(2 * math.pi) * sigmaList[i])
        plt.plot(x, y_sig, "r-", color=colors[i],linewidth=1)

    plt.rcParams['font.sans-serif'] = ['Times New Roman'] # setting font
    plt.rcParams['axes.unicode_minus'] = False  # to show minus
    plt.xlabel("age/Ma")
    plt.ylabel("frequency")
    plt.show()

if __name__=='__main__':
    main()