These codes were written by Xianjun Fang.
There are four code files.
FFunction.py provides necessary functions for the rest three code files.
F01Gaussian_fitting.py is to get results of Gaussian fitting.
F02Real_peak_distribution.py is to obtain real distribution of every peak.
F03Continental_crustal_evolution_units.py is the most crucial file which is to get continental crustal units based on same background and similar background.

The needed python packages include numpy, matplotlib, sklearn, basemap.

'gadm36_CHN_1', which show the state boundaries of China, are files from https://gadm.org/index.html.
'Country', which show the national boundaries of the World, are files provided by Lei Zhang, one of co-writers.
A csv file is needed to put in the same directory to run those codes and its format should be as same as the dataset we provided.

